import { Component } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-test',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'From controller';
  name = 'Sample text';	
}
