import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';

declare var $:any;

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})


export class ContactComponent implements OnInit {

	townHalls = ['Town Hall 10', 'Town Hall 9', 'Town Hall 8', 'Town Hall 7', 'Town Hall 6', 'Town Hall 5', 'Just Started Playing'];


	submitForm(f: NgForm) { 
		//console.log(f.value);
		if ($('#contact_form').validator('validate').has('.has-error').length) {
        	//alert('Server error, please try again after sometime!');
      	} else {
        	 $.ajax({
			    url: "//formspree.io/bengalkillers2015@gmail.com", 
			    method: "POST",
			    data: f.value,
			    dataType: "json",
			     success: function(data) {
			     	//console.log(JSON.stringify(data));
			     	$('#contact_form')[0].reset();
			       $('#success_message').slideDown({ opacity: "show" }, "slow");
			   },
			    error: function() {
			      alert('Server error, please try again later!');
			   }
			});
      	}
  	}  /*Submin ends*/

  constructor() { 

  }

  ngOnInit() {

  }

}
